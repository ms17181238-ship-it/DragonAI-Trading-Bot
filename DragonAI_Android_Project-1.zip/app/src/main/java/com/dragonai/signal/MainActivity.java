package com.dragonai.signal;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.Locale;

public class MainActivity extends Activity {
    EditText open, high, low, close;
    TextView signal, reason, candle, score, history;
    LinearLayout root;
    String historyText = "সিগন্যাল হিস্ট্রি এখানে দেখা যাবে।";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUI();
    }

    int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density); }

    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    void buildUI() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        root.setBackgroundColor(Color.rgb(12,16,25));
        scroll.addView(root);

        TextView title = text("🐉 DRAGON AI", 28, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView subtitle = text("QUOTEX • M1 SIGNAL ANALYZER", 13, Color.rgb(170,183,204), true);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);
        gap(18);

        signal = text("WAIT", 34, Color.rgb(255,203,77), true);
        signal.setGravity(Gravity.CENTER);
        signal.setPadding(0, dp(18), 0, dp(8));
        root.addView(signal);
        reason = text("সিগন্যাল তৈরি করতে ক্যান্ডেলের OHLC তথ্য দিন।", 14, Color.WHITE, false);
        reason.setGravity(Gravity.CENTER);
        root.addView(reason);
        score = text("বিশ্লেষণ স্কোর: —", 14, Color.rgb(170,183,204), true);
        score.setGravity(Gravity.CENTER);
        root.addView(score);
        gap(18);

        root.addView(text("সর্বশেষ ১ মিনিটের ক্যান্ডেল (OHLC)", 17, Color.WHITE, true));
        root.addView(text("চার্টের একই ক্যান্ডেলের Open, High, Low, Close বসান।", 13, Color.rgb(170,183,204), false));
        open = field("Open মূল্য");
        high = field("High মূল্য");
        low = field("Low মূল্য");
        close = field("Close মূল্য");
        gap(8);

        Button analyze = new Button(this);
        analyze.setText("ANALYZE SIGNAL");
        analyze.setTextSize(15);
        analyze.setOnClickListener(v -> analyze());
        root.addView(analyze, new LinearLayout.LayoutParams(-1, dp(52)));
        gap(10);

        candle = text("ক্যান্ডেল বিশ্লেষণ: —", 14, Color.WHITE, false);
        root.addView(candle);
        gap(18);
        root.addView(text("সিগন্যাল হিস্ট্রি", 18, Color.WHITE, true));
        history = text(historyText, 13, Color.rgb(190,201,218), false);
        root.addView(history);
        gap(20);
        TextView warning = text("গুরুত্বপূর্ণ: এটি OHLC ইনপুট-ভিত্তিক পরীক্ষামূলক বিশ্লেষক। এটি Quotex-এর লাইভ ডেটা নেয় না, ট্রেড করে না এবং লাভ নিশ্চিত করে না। ডেমোতে যাচাই করুন।", 12, Color.rgb(255,190,120), false);
        root.addView(warning);
        setContentView(scroll);
    }

    EditText field(String hint) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(145,157,177));
        e.setTextColor(Color.WHITE);
        e.setInputType(8194);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(74,92,120)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.topMargin = dp(7);
        root.addView(e, lp);
        return e;
    }

    void gap(int h) {
        Space s = new Space(this);
        root.addView(s, new LinearLayout.LayoutParams(1, dp(h)));
    }

    double val(EditText e) { return Double.parseDouble(e.getText().toString().trim()); }

    void analyze() {
        try {
            double o=val(open), h=val(high), l=val(low), c=val(close);
            if (h < Math.max(o,c) || l > Math.min(o,c) || h < l || l < 0) {
                Toast.makeText(this, "OHLC মানগুলো যাচাই করুন", Toast.LENGTH_LONG).show(); return;
            }
            double range = h-l;
            if (range == 0) {
                signal.setText("WAIT"); signal.setTextColor(Color.rgb(255,203,77));
                reason.setText("দামের রেঞ্জ নেই; পরিষ্কার সংকেত পাওয়া যায়নি।");
                score.setText("বিশ্লেষণ স্কোর: 0%");
                candle.setText("ক্যান্ডেল বিশ্লেষণ: নিরপেক্ষ");
                addHistory("WAIT — রেঞ্জ শূন্য");
                return;
            }
            double body = Math.abs(c-o);
            double bodyPct = body/range*100.0;
            double closePos = (c-l)/range*100.0;
            double upper = h-Math.max(o,c);
            double lower = Math.min(o,c)-l;
            String s = "WAIT", why = "ক্যান্ডেল থেকে একা নির্ভরযোগ্য দিক বোঝা যাচ্ছে না।";
            int col = Color.rgb(255,203,77);
            double confidence = Math.min(95, Math.max(10, bodyPct*0.55 + Math.abs(closePos-50)*0.45));
            if (c > o && bodyPct >= 55 && closePos >= 70) {
                s="UP"; col=Color.rgb(76,220,139);
                why="বুলিশ ক্যান্ডেল, বড় বডি এবং ক্লোজ হাইয়ের কাছাকাছি।";
            } else if (c < o && bodyPct >= 55 && closePos <= 30) {
                s="DOWN"; col=Color.rgb(255,105,105);
                why="বেয়ারিশ ক্যান্ডেল, বড় বডি এবং ক্লোজ লোয়ের কাছাকাছি।";
            }
            signal.setText(s); signal.setTextColor(col);
            reason.setText(why);
            score.setText(String.format(Locale.US, "প্রাথমিক ক্যান্ডেল স্কোর: %.0f%% (জয়ের সম্ভাবনা নয়)", confidence));
            String dir = c>o ? "BULLISH / সবুজ" : c<o ? "BEARISH / লাল" : "DOJI / সমান";
            String pressure = lower > upper*1.5 ? "নিচে লম্বা উইক: নিচে প্রত্যাখ্যানের ইঙ্গিত" :
                              upper > lower*1.5 ? "উপরে লম্বা উইক: উপরে প্রত্যাখ্যানের ইঙ্গিত" :
                              "উইক তুলনামূলক ভারসাম্যপূর্ণ";
            candle.setText(String.format(Locale.US,
                "ক্যান্ডেল: %s\\nবডি: %.1f%% • ক্লোজ পজিশন: %.1f%%\\n%s", dir, bodyPct, closePos, pressure));
            addHistory(s + " — " + why);
        } catch (Exception ex) {
            Toast.makeText(this, "চারটি মূল্য সঠিকভাবে লিখুন", Toast.LENGTH_LONG).show();
        }
    }

    void addHistory(String item) {
        String stamp = new java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new java.util.Date());
        historyText = stamp + "  " + item + "\\n" + historyText;
        if (historyText.length() > 1800) historyText = historyText.substring(0,1800);
        history.setText(historyText);
    }
}
